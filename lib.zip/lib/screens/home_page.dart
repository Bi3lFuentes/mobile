import 'package:teste/screens/cadastro_page.dart' show CadastroPage;
import 'package:flutter/material.dart';
import 'package:teste/screens/listar_propriedade.dart';
import 'package:teste/screens/tabelas_db_page.dart';
import 'cadastrar_user.dart';
import 'cadastro_page.dart';
import 'listar_user.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Home Page"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Botão que leva para a tela CADASTRO
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CadastrarUserPage()),
                );
              },
              child: const Text('Cadastrar usuário'),
            ),
            const SizedBox(height: 20), // Espaçamento
            //Botão 2
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const CadastroPage()),
                );
              },
              child: const Text('Cadastrar propriedade'),
            ),
            const SizedBox(height: 20), // Espaçamento
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const TabelasDBPage()),
                );
              },
              child: const Text('Listar tabelas'),
            ),
            const SizedBox(height: 20), // Espaçamento
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ListarUserPage()),
                );
              },
              child: const Text('Listar usuários'),
            ),
            const SizedBox(height: 20), // Espaçamento
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ListarPropriedadesPage()),
                );
              },
              child: const Text('Listar propriedades'),
            ),
          ],
        ),
      ),
    );
  }
}
