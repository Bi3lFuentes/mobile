import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static final AppDatabase _instance = AppDatabase._internal();
  static Database? _database;

  factory AppDatabase() => _instance;

  AppDatabase._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final path = join(await getDatabasesPath(), 'student_database.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE usuarios(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            password TEXT
          )
        ''');

        await db.execute('''
          CREATE TABLE propriedades(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome_entrevistado TEXT,
            nome_propriedade TEXT,
            localidade TEXT,
            produto TEXT,
            sistema_cultivo TEXT,     
            localizacao TEXT       
          )
        ''');
      },
    );
  }

  /// ✅ Insere um usuário na tabela 'usuarios'
  Future<void> inserirUsuario(String nome, String email, String senha) async {
    final db = await database;
    await db.insert(
      'usuarios',
      {
        'name': nome,
        'email': email,
        'password': senha,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// ✅ Lista todos os usuários cadastrados
  Future<List<Map<String, dynamic>>> listarUsuarios() async {
    final db = await database;
    return await db.query('usuarios');
  }


  Future<void> inserirPropriedade(
      String nomeEntrevistado,
      String nomePropriedade,
      String localidade,
      String produto,
      String sistemaCultivo,
      String localizacao, // Campo de localização adicionado
      ) async {
    final db = await database;
    await db.insert(
      'propriedades',
      {
        'nome_entrevistado': nomeEntrevistado,
        'nome_propriedade': nomePropriedade,
        'localidade': localidade,
        'produto': produto,
        'sistema_cultivo': sistemaCultivo,
        'localizacao': localizacao, // Incluído aqui
      },
    );
  }
}
