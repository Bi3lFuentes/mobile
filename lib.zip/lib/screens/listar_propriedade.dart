import 'package:flutter/material.dart';
import 'package:teste/screens/AppDatabase.dart';
import 'package:teste/screens/EditarPropriedadePage.dart'; // Importe a tela de edição

class ListarPropriedadesPage extends StatefulWidget {
  const ListarPropriedadesPage({Key? key}) : super(key: key);

  @override
  _ListarPropriedadesPageState createState() => _ListarPropriedadesPageState();
}

class _ListarPropriedadesPageState extends State<ListarPropriedadesPage> {
  List<Map<String, dynamic>> propriedades = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    carregarPropriedades();
  }

  Future<void> excluirPropriedade(int id) async {
    final db = await AppDatabase().database;
    await db.delete('propriedades', where: 'id = ?', whereArgs: [id]);
    carregarPropriedades();
  }

  Future<void> carregarPropriedades() async {
    final db = await AppDatabase().database;
    final resultado = await db.query('propriedades');
    setState(() {
      propriedades = resultado;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lista de Propriedades'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() => isLoading = true);
              carregarPropriedades();
            },
          )
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : propriedades.isEmpty
          ? const Center(child: Text('Nenhuma propriedade cadastrada.'))
          : ListView.builder(
        itemCount: propriedades.length,
        itemBuilder: (context, index) {
          final propriedade = propriedades[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            child: ListTile(
              title: Text(propriedade['nome_propriedade'] ?? 'Sem nome'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Entrevistado: ${propriedade['nome_entrevistado'] ?? 'Não informado'}'),
                  Text('Localidade: ${propriedade['localidade'] ?? 'Não informada'}'),
                  Text('Produto: ${propriedade['produto'] ?? 'Não informado'}'),
                  Text('Sistema: ${propriedade['sistema_cultivo'] ?? 'Não informado'}'),
                  Text('Localização: ${propriedade['localizacao'] ?? 'Não informada'}'),
                ],
              ),
              leading: CircleAvatar(child: Text(propriedade['id'].toString())),
              trailing: PopupMenuButton<String>(
                onSelected: (value) async {
                  if (value == 'editar') {
                    final resultado = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EditarPropriedadePage(propriedade: propriedade),
                      ),
                    );
                    if (resultado == true) {
                      carregarPropriedades();
                    }
                  } else if (value == 'excluir') {
                    excluirPropriedade(propriedade['id']);
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(value: 'editar', child: Text('Editar')),
                  const PopupMenuItem(value: 'excluir', child: Text('Excluir')),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
